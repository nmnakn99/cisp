<?php
class customer_model extends CI_Model{
    public function getRecords(){
        $qry=$this->db->get('customer');
        if($qry->num_rows()>0){
            return $qry->result();
        }
    }
    public function deleterecord($id){
        return $this->db->delete('customer',array('idcustomer'=>$id));
        }
        public function updaterecord($id,$data){
            return $this->db->where('idcustomer',$id)->update('customer',$data);
            }
    public function saveRecord($data){
                return $this->db->insert('customer', $data);
                }
                            
        
}
?> 