<?php
class invoice_model extends CI_Model{
    public function getRecords(){
        $qry=$this->db->get('pos');
        if($qry->num_rows()>0){
            return $qry->result();
        }
    }
    public function deleterecord($id){
        $tables = array('pos', 'pos_detail');
        $this->db->where('idpos ', $id);
        $this->db->where('idpos ', $id);
        $this->db->delete($tables);
        }
}
?> 