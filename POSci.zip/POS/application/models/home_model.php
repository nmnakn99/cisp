<?php
class home_model extends CI_Model{
    public function getCustomer($id){
        $data=$this->db->query("SELECT idcustomer,namacustomer,alamat FROM customer where idcustomer LIKE '%" .$id. "%' ")->result();
        return $data;
   }
   public function getProduct($id){
    $data=$this->db->query("SELECT idproduk,namaproduk,harga FROM produk where idproduk LIKE '%" .$id. "%' ")->result();
    return $data;
}
 public function SimpanPOS($data){
    $this->db->insert('pos', $data);
    return  $data['idpos'];
} 
public function SimpanPOSDetail($data){
    return $this->db->insert_batch('pos_detail', $data);  
}
public function getidcus($id){
    $data=$this->db->query("SELECT customer.idcustomer,customer.namacustomer,GROUP_CONCAT(pos.idpos) as idpos,GROUP_CONCAT(pos.tanggal) as tanggal,GROUP_CONCAT(pos.termin) as termin,GROUP_CONCAT(pos.total) as total FROM pos left join customer on pos.idcustomer=customer.idcustomer where pos.status='0' and customer.idcustomer LIKE '%" .$id. "%' group by customer.idcustomer")->result();
    return $data;
}
public function bayarPOS($id,$data){
    return $this->db->where('idpos',$id)->update('pos',$data);
}
public function lunaskan($data){
    return $this->db->insert('pelunasan', $data);
}

} 
?>