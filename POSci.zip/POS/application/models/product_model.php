<?php
class product_model extends CI_Model{
    public function getRecords(){
        $qry=$this->db->get('produk');
        if($qry->num_rows()>0){
            return $qry->result();
        }
    }
    public function updaterecord($id,$data){
        return $this->db->where('idproduk',$id)->update('produk',$data);
        }
        public function deleterecord($id){
            return $this->db->delete('produk',array('idproduk'=>$id));
            }
public function saveRecord($data){
            return $this->db->insert('produk', $data);
            }
   
}
?> 