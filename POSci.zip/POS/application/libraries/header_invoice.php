<?php require_once(APPPATH.'/third_party/fpdf/fpdf.php');
class header_invoice extends FPDF{
	public function Header(){
		$this->Image('assets/img/sclogo.png',3,1,2);
		$this->SetTextColor(0);
		$this->SetFont('Arial','B','12');
		$this->Cell(13,1,'SEBUAH CHANNEL',0,0,'C');
		$this->Ln($h=0.4);
		$this->SetFont('Arial','','9');
		$this->Cell(12.7,1,'Sistem Penjualan (Kredit)',0,0,'C');
		$this->Ln($h=0.4);
		$this->Line(3,3.1,18,3.1);
		$this->SetLineWidth(0.1);
		$this->Line(3,3.1,18,3.1);
		$this->SetLineWidth(0);
		$this->Ln();
		$this->Ln();
		$this->SetFont('Arial','B','14');
		$this->Cell(19,1,'Invoice',0,0,'C');
		$this->Ln();		
			}
}
?>