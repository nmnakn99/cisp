<?php
class fungsi{
	function __construct(){
		require_once(APPPATH.'/third_party/deskripsi.php');
	}
}
?>