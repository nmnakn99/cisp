<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends CI_Controller{
    function __construct(){
		parent::__construct();
        $this->load->helper('url');
        $this->load->model('home_model');
        if(  $this->session->userdata('users')!=TRUE){
            redirect('login');
        }
    }
    public function index(){
        $this->load->view('home');
        $this->load->view('dasboard');
    }
public function simpan(){
    date_default_timezone_set('Asia/Jakarta');
    $idcustomer=$this->input->post('idcustomer');
    $pos=$this->input->post('pos');
    $tgl=$this->input->post('tglinv');
    $angka=$this->input->post('termin');
    $total=$this->input->post('total');
    $termin = date('Y-m-d', strtotime('+'.$angka.' days'));
    $data1 = array(
         'idpos'=>time(),
         'idcustomer' => $idcustomer,
         'tanggal'=> $tgl,
         'total'=> $total,
         'termin'=> $termin,
         'status'=> '0'
     );
$id=$this->home_model->SimpanPOS($data1); 
  for ($i = 0; $i < count($pos); $i++){
    $subtotal= $pos[$i]["harga"] * $pos[$i]["qty"];
    $data2[] = array(
        'idpos'=>$id,
        'idproduk' => $pos[$i]["idproduk"],
        'harga'=> $pos[$i]["harga"],
        'qty'=> $pos[$i]["qty"],
        'subtotal'=>$subtotal
     );
 } 
$this->home_model->SimpanPOSDetail($data2); 
$respon[]=array(
    "message"=>"Sukses"
);
echo json_encode($respon);
}
public function bayar(){
    $id=$this->input->post('invid');
    $tgl=$this->input->post('tgl');
    $batas=$this->input->post('batas');
    $total=$this->input->post('total');
    $waktu = strtotime($tgl) - strtotime($batas);
    $days = $waktu/(60 * 60 * 24);
    if($days>0 ){
    $bayar=$total;
    $diskon='0';
    }else{
    $diskon=($total * 10) / 100;
    $bayar=$total-$diskon;
    }
         $data=array(
             "status"=> '1',
             "pelunasan"=>$tgl,
             "bayar"=>$bayar,
             "diskon"=>$diskon
         );
    $this->home_model->bayarPOS($id,$data);
     $respon[]=array(
        "message"=>"Sukses"
    );
    echo json_encode($respon); 
} 
    public function customer(){
        $id=$this->input->get('term');
    $record=$this->home_model->getCustomer($id);
         foreach($record as $rs){
             $customer[]=array(
                 "value"=>$rs->idcustomer,
                 "idcustomer"=>$rs->idcustomer,
                 "namacustomer"=>$rs->namacustomer,
                 "alamat"=>$rs->alamat
             );
         } 
         echo json_encode($customer);
    }
    public function produk(){
        $id=$this->input->get('term');
    $record=$this->home_model->getProduct($id);
         foreach($record as $rs){
             $product[]=array(
                 "value"=>$rs->idproduk,
                 "idproduk"=>$rs->idproduk,
                 "namaproduk"=>$rs->namaproduk,
                 "harga"=>$rs->harga
             );
         } 
         echo json_encode($product);
    }
    /* public function user(){
        $id=$this->input->get('term');
    $record=$this->home_model->getUser($id);
         foreach($record as $rs){
             $customer[]=array(
                 "value"=>$rs->iduser,
                 "iduser"=>$rs->iduser,
                 "namauser"=>$rs->namauser,
                 "jabatan"=>$rs->jabatan
             );
         } 
         echo json_encode($user);
    } */
    public function cus(){
        $id=$this->input->get('term');
    $record=$this->home_model->getidcus($id);
         foreach($record as $rs){
            $idp=$rs->idpos;
            $idpos=explode(',',$idp);
            $tgl=$rs->tanggal;
            $tanggal=explode(',',$tgl);
            $ttl=$rs->total;
            $total=explode(',',$ttl);
            $trmn=$rs->termin;
            $termin=explode(',',$trmn);
             $customer[]=array(
                 "value"=>$rs->idcustomer,
                 "idcustomer"=>$rs->idcustomer,
                 "namacustomer"=>$rs->namacustomer,
                 "detail"=>array('idpos'=>$idpos,'tanggal'=>$tanggal,'total'=>$total,'termin'=>$termin),
             );
		} 
         echo json_encode($customer);
    }    
}
?>