<?php defined('BASEPATH') OR exit('No direct script access allowed');
class print_invoice extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->library('header_invoice');
        $this->load->library('indotgl');
	}
     function invoice($idpos){
$pdf=new header_invoice('L','cm','A5');	
$pdf->Open();
$pdf->AliasNbPages();
$pdf->AddPage();
$row1='No. Invoice';
$row2='Tgl Invoice';
$row3='Customer';
$row4='Alamat Cust.';
$row5='Termin';
$row8='Telp Cust.';
$row6='Total';
$tglindo=tgl(date("Y-m-d"));
$row7="Jakarta, ";
$pdf->SetFont('Arial','','9');
$pdf->SetTextColor(0);
$data=$this->db->query("SELECT pos.idpos,pos.termin,pos.tanggal,customer.namacustomer,customer.telepon,customer.alamat,pos.total,pos.termin FROM pos left join customer on pos.idcustomer=customer.idcustomer WHERE pos.idpos LIKE '".$idpos. "%'")->result();
foreach ($data as $row){
$pdf->Cell(2);
$pdf->Cell(2,0.5,$row3,0,0,'L');
$pdf->Cell(0.5,0.5,':',0,0,'C');
$pdf->Cell(7,0.5,$row->namacustomer,0,0,'L');
$pdf->Cell(2,0.5,$row1,0,0,'L');
$pdf->Cell(0.5,0.5,':',0,0,'C');
$pdf->Cell(4,0.5,$row->idpos,0,1,'L');
$pdf->Cell(2);
$pdf->Cell(2,0.5,$row4,0,0,'L');
$pdf->Cell(0.5,0.5,':',0,0,'C');
$pdf->Cell(7,0.5,$row->alamat,0,0,'L');
$pdf->Cell(2,0.5,$row2,0,0,'L');
$pdf->Cell(0.5,0.5,':',0,0,'C');
$pdf->Cell(4,0.5,tgl($row->tanggal),0,1,'L');
$pdf->Cell(2);
$pdf->Cell(2,0.5,$row8,0,0,'L');
$pdf->Cell(0.5,0.5,':',0,0,'C');
$pdf->Cell(7,0.5,$row->telepon,0,0,'L');
$pdf->Cell(2,0.5,$row5,0,0,'L');
$pdf->Cell(0.5,0.5,':',0,0,'C');
$pdf->Cell(4,0.5,tgl($row->termin),0,1,'L');
}
$pdf->Ln($h=0.5);
		$pdf->SetFont('Arial','B','9');
		$pdf->SetFillColor(255,0,0);
		$pdf->SetLineWidth(0.01);
		$pdf->SetDrawColor(255,0,0);
		$pdf->SetTextColor(255);
		$pdf->Cell(2);
		$pdf->Cell(1,0.5,'No','LTB',0,'C',1);
		$pdf->Cell(2,0.5,'ID Produk','LTB',0,'C',1);		
		$pdf->Cell(5,0.5,'Nama Produk','LTB',0,'C',1);
		$pdf->Cell(2,0.5,'Harga','LTB',0,'C',1);
		$pdf->Cell(2,0.5,'Qty','LTB',0,'C',1);
		$pdf->Cell(3,0.5,'Amount','LRTB',0,'C',1);
        $pdf->Ln();	
        $pdf->SetFont('Arial','','8');
        $pdf->SetTextColor(0);
        $pdf->SetLineWidth(0.01);
        $pdf->SetDrawColor(255,0,0);
$data=$this->db->query("SELECT pos.idpos,pos_detail.idproduk,produk.namaproduk,produk.harga,pos_detail.qty,pos_detail.subtotal FROM pos left join pos_detail on pos.idpos=pos_detail.idpos left join produk on produk.idproduk=pos_detail.idproduk WHERE pos_detail.idpos  LIKE '".$idpos. "%' group by pos_detail.idproduk")->result();
$i=1;
foreach ($data as $row){
    $pdf->Cell(2);
	$pdf->Cell(1,0.5,$i++,'LB',0,'C');
    $pdf->Cell(2,0.5,$row->idproduk,'LB',0,'C');
	$pdf->Cell(5,0.5,$row->namaproduk,'LB',0,'L');
	$pdf->Cell(2,0.5,format_angka($row->harga),'LB',0,'C');
	$pdf->Cell(2,0.5,format_angka($row->qty),'LB',0,'C');
	$pdf->Cell(3,0.5,format_angka($row->subtotal),'LRB',0,'C');
$pdf->Ln();
}
$dta=$this->db->query("SELECT sum(subtotal) as tot,pos.tanggal,pos.status,pos.pelunasan,pos.bayar,pos.diskon FROM pos_detail left join pos on pos.idpos=pos_detail.idpos WHERE pos.idpos LIKE '".$idpos. "%'")->result();
foreach ($dta as $rw){
$pdf->Ln($h=0.5);
$pdf->Cell(2);
if($rw->status != '0'){
	$pdf->Image('assets/img/cappaid.jpg',7,3.5,2);
	$pdf->SetFont('Arial','','9');
$pdf->Cell(1.8,0.5,'SubTotal',0,'C');
$pdf->Cell(6,0.5,'Rp'.format_angka($rw->tot),0,0,'L');
$pdf->Cell(3,0.5,'Tanggal Pelunasan',0,'L');
$pdf->Cell(2,0.5,': '.tgl($rw->pelunasan),0,1,'L');
$pdf->Cell(2);
$pdf->SetFont('Arial','','9');
$pdf->Cell(1.6,0.5,'Disc. 10%',0,'C');
$pdf->Cell(2,0.5,': Rp'.format_angka($rw->diskon),0,1,'L');
$pdf->Cell(2);
$pdf->SetFont('Arial','B','9');
$pdf->Cell(1.6,0.5,'Total',0,'C');
$pdf->Cell(2,0.5,': Rp'.format_angka($rw->bayar),0,1,'L');
}else{
	$pdf->SetFont('Arial','B','9');
$pdf->Cell(1.8,0.5,'Total',0,'C');
$pdf->Cell(6,0.5,'Rp'.format_angka($rw->tot),0,0,'L');
}
$pdf->Ln();
/* $pdf->Cell(12.5);
$pdf->SetFont('Arial','','11');
$pdf->MultiCell(0,0.5,$row7.tgl($rw->tanggal),0,'L');  */
}
$pdf->Output($name='invoice.pdf',$dest='I');
    }
}
?>