<?php defined('BASEPATH') OR exit('No direct script access allowed');
class  User extends CI_Controller{
    function __construct(){

		parent::__construct();
        $this->load->helper('url');
        $this->load->view('home');
        $this->load->library('fungsi');
        $this->load->model('user_model');
        if(  $this->session->userdata('users')!=TRUE){
            redirect('login');
        }
    }
    public function index(){
        $records=$this->user_model->getRecords();
        $this->load->view('user',['records'=>$records]); 
    }
    public function insert(){
        require_once(APPPATH.'libraries/password.php');
        $pwd=$_POST['password'];
        $password=password_hash($pwd, PASSWORD_DEFAULT,['cost'=>12]);
            if ($password){
        $data=array(
        "iduser"=>$_POST["iduser"],
        "namauser"=>$_POST["namauser"],
        "password"=>$password,
        "jabatan"=>$_POST["jabatan"]
        );
        $this->user_model->saveRecord($data);
        redirect('user');
    }
        } 
    public function delete($id){
        $record=$this->user_model->deleterecord($id);
        redirect('user');
        }
        public function update($id){
            require_once(APPPATH.'libraries/password.php');
            $pwd=$_POST['epassword'];
            $password=password_hash($pwd, PASSWORD_DEFAULT,['cost'=>12]);
            if ($password){
            $data=array(
                "password"=>$password
                );
            $record=$this->user_model->updaterecord($id,$data);
            redirect('user');
            }
            }
            
        
}
?>