<?php defined('BASEPATH') OR exit('No direct script access allowed');
class report_produk extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->library('pdf');
        $this->load->library('indotgl');
    }
     function index(){
$pdf=new FPDF('P','cm','A4');		
$pdf->Open();
$pdf->AliasNbPages();
$pdf->AddPage();
        $pdf->Image('assets/img/sclogo.png',3.5,1,2);
        $pdf->SetTextColor(0);
		$pdf->SetFont('Arial','B','12');
		$pdf->Cell(14,1,'SEBUAH CHANNEL',0,0,'C');
		$pdf->Ln($h=0.4);
		$pdf->SetFont('Arial','','9');
		$pdf->Cell(13.7,1,'Sistem Penjualan (Kredit)',0,0,'C');
		$pdf->Ln($h=0.4);
		$pdf->Line(3.5,3.1,17.4,3.1);
		$pdf->SetLineWidth(0.1);
		$pdf->Line(3.5,3.1,17.4,3.1);
		$pdf->SetLineWidth(0);
		$pdf->Ln();
		$pdf->Ln();
		$pdf->SetFont('Arial','B','14');
		$pdf->Cell(19,1,'Data Produk',0,0,'C');
		$pdf->Ln($h=1.5);
		$pdf->SetFont('Arial','B','9');
		$pdf->SetFillColor(255,0,0);
		$pdf->SetLineWidth(0.01);
		$pdf->SetDrawColor(255,0,0);
		$pdf->SetTextColor(255);
		$pdf->Cell(2.4);
		$pdf->Cell(2,0.5,'ID Produk','LTB',0,'C',1);		
		$pdf->Cell(5,0.5,'Nama Produk','LTB',0,'C',1);
		$pdf->Cell(2,0.5,'Harga','LTB',0,'C',1);
		$pdf->Cell(2,0.5,'Qty','LTB',0,'C',1);
		$pdf->Cell(3,0.5,'Subtotal','LRTB',0,'C',1);
        $pdf->Ln();	
$pdf->SetFont('Arial','','8');
$pdf->SetTextColor(0);
$pdf->SetLineWidth(0.01);
$pdf->SetDrawColor(255,0,0);
$data=$this->db->query("SELECT idproduk, namaproduk,harga,qty FROM produk group by idproduk")->result();
foreach ($data as $row){
	$pdf->Cell(2.4);
	//$pdf->Cell(1,0.5,$j+1,'LB',0,'C', $fill);
	$pdf->Cell(2,0.5,$row->idproduk,'LB',0,'C');
	$pdf->Cell(5,0.5,$row->namaproduk,'LB',0,'L');
	$pdf->Cell(2,0.5,format_angka($row->harga),'LB',0,'C');
	$pdf->Cell(2,0.5,format_angka($row->qty),'LB',0,'C');
	$pdf->Cell(3,0.5,format_angka($row->harga * $row->qty),'LRB',0,'C');
$pdf->Ln();
}
$dta=$this->db->query("SELECT sum(qty) as jum, sum(qty * harga) as tot FROM produk")->result();
foreach ($dta as $rw){
$pdf->Ln($h=1);
$pdf->Cell(10);
$pdf->SetFont('Arial','B','11');

$pdf->Cell(2,0.5,'Total',0,'C');
$pdf->Cell(2,0.5,format_angka($rw->jum),0,'C');
$pdf->Cell(2,0.5,format_angka($rw->tot),0,'C');
$pdf->Ln();
}

$pdf->Output($name='data-produk.pdf',$dest='I');
    } 
   
}
?>