<?php defined('BASEPATH') OR exit('No direct script access allowed');
class report_customer extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->library('pdf');
        $this->load->library('indotgl');
    }
     function index(){
$pdf=new FPDF('L','cm','A4');		
$pdf->Open();
$pdf->AliasNbPages();
$pdf->AddPage();
        $pdf->Image('assets/img/sclogo.png',3.5,1,2);
        $pdf->SetTextColor(0);
		$pdf->SetFont('Arial','B','12');
		$pdf->Cell(14,1,'SEBUAH CHANNEL',0,0,'C');
		$pdf->Ln($h=0.4);
		$pdf->SetFont('Arial','','9');
		$pdf->Cell(13.7,1,'Sistem Penjualan (Kredit)',0,0,'C');
		$pdf->Ln($h=0.4);
		$pdf->Line(3.5,3.1,26.4,3.1);
		$pdf->SetLineWidth(0.1);
		$pdf->Line(3.5,3.1,26.4,3.1);
		$pdf->SetLineWidth(0);
		$pdf->Ln();
		$pdf->Ln();
		$pdf->SetFont('Arial','B','14');
		$pdf->Cell(29,1,'Data Customer',0,0,'C');
		$pdf->Ln($h=1.5);
		$pdf->SetFont('Arial','B','9');
		$pdf->SetFillColor(255,0,0);
		$pdf->SetLineWidth(0.01);
		$pdf->SetDrawColor(255,0,0);
		$pdf->SetTextColor(255);
		$pdf->Cell(2.4);
		//$this->Cell(1,0.5,'No','LTB',0,'C',1);
		$pdf->Cell(3,0.5,'ID Customer','LTB',0,'C',1);		
		$pdf->Cell(5,0.5,'Nama Customer','LTB',0,'C',1);
		$pdf->Cell(8,0.5,'Alamat','LTB',0,'C',1);
		$pdf->Cell(2,0.5,'Telepon','LTB',0,'C',1);
		$pdf->Cell(5,0.5,'Email','LRTB',0,'C',1);
        $pdf->Ln();	
$pdf->SetFont('Arial','','8');
$pdf->SetTextColor(0);
$pdf->SetLineWidth(0.01);
$pdf->SetDrawColor(255,0,0);
$data=$this->db->query("SELECT idcustomer, namacustomer,alamat,telepon,email FROM customer order by idcustomer asc")->result();
foreach ($data as $row){
	$pdf->Cell(2.4);
	//$pdf->Cell(1,0.5,$j+1,'LB',0,'C', $fill);
	$pdf->Cell(3,0.5,$row->idcustomer,'LB',0,'C');
	$pdf->Cell(5,0.5,$row->namacustomer,'LB',0,'L');
	$pdf->Cell(8,0.5,$row->alamat,'LB',0,'L');
	$pdf->Cell(2,0.5,$row->telepon,'LB',0,'C');
	$pdf->Cell(5,0.5,$row->email,'LRB',0,'L');
$pdf->Ln();
}
$pdf->Output($name='data-customer.pdf',$dest='I');
    } 
   
}
?>