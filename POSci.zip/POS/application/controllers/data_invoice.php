<?php defined('BASEPATH') OR exit('No direct script access allowed');
class data_invoice extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->library('pdf');
        $this->load->library('indotgl');
    }
     function index(){
        $date1=$_POST['dari'];
        $date2=$_POST['sampai'];
$pdf=new FPDF('L','cm','A4');		
$pdf->Open();
$pdf->AliasNbPages();
$pdf->AddPage();
        $pdf->Image('assets/img/sclogo.png',3.5,1,2);
        $pdf->SetTextColor(0);
		$pdf->SetFont('Arial','B','12');
		$pdf->Cell(14,1,'SEBUAH CHANNEL',0,0,'C');
		$pdf->Ln($h=0.4);
		$pdf->SetFont('Arial','','9');
		$pdf->Cell(13.7,1,'Sistem Penjualan (Kredit)',0,0,'C');
		$pdf->Ln($h=0.4);
		$pdf->Line(3.5,3.1,26.4,3.1);
		$pdf->SetLineWidth(0.1);
		$pdf->Line(3.5,3.1,26.4,3.1);
		$pdf->SetLineWidth(0);
		$pdf->Ln();
		$pdf->Ln();
		$pdf->SetFont('Arial','B','14');
        $pdf->Cell(29,1,'Data Invoice',0,0,'C');
		$pdf->Ln($h=0.5);
		$pdf->SetFont('Arial','B','12');
		$pdf->Cell(29,1,'Periode '.tgl($date1).' s/d '.tgl($date2),0,0,'C');
		$pdf->Ln($h=1.5);
		$pdf->SetFont('Arial','B','9');
		$pdf->SetFillColor(255,0,0);
		$pdf->SetLineWidth(0.01);
		$pdf->SetDrawColor(255,0,0);
		$pdf->SetTextColor(255);
		$pdf->Cell(2.4);
		$pdf->Cell(1,0.5,'No','LTB',0,'C',1);
		$pdf->Cell(2,0.5,'No. Invoice','LTB',0,'C',1);	
		$pdf->Cell(2,0.5,'Tgl Invoice','LTB',0,'C',1);		
		$pdf->Cell(2,0.5,'ID Customer','LTB',0,'C',1);		
		$pdf->Cell(6,0.5,'Nama Customer','LTB',0,'C',1);	
		$pdf->Cell(3,0.5,'Amount','LTB',0,'C',1);
		$pdf->Cell(2,0.5,'Termin','LTB',0,'C',1);
		$pdf->Cell(2,0.5,'Tgl Lunas','LTB',0,'C',1);
		$pdf->Cell(3,0.5,'Status','LRTB',0,'C',1);
        $pdf->Ln();	
$pdf->SetFont('Arial','','8');
$pdf->SetTextColor(0);
$pdf->SetLineWidth(0.01);
$pdf->SetDrawColor(255,0,0);
$data=$this->db->query("SELECT pos.idpos,pos.idcustomer,pos.total,pos.tanggal,pos.termin,customer.namacustomer,pos.status,pos.pelunasan FROM pos left join customer on pos.idcustomer=customer.idcustomer WHERE pos.tanggal BETWEEN '$date1' AND '$date2' group by pos.idpos order by pos.tanggal asc")->result();
$i=1;
foreach ($data as $row){
	$pdf->Cell(2.4);
	$pdf->Cell(1,0.5,$i++,'LB',0,'C');
	$pdf->Cell(2,0.5,$row->idpos,'LB',0,'C');
	$pdf->Cell(2,0.5,$row->tanggal,'LB',0,'C');
	$pdf->Cell(2,0.5,$row->idcustomer,'LB',0,'L');
	$pdf->Cell(6,0.5,$row->namacustomer,'LB',0,'L');
	$pdf->Cell(3,0.5,format_angka($row->total),'LB',0,'C');
	$pdf->Cell(2,0.5,$row->termin,'LB',0,'C');
	$pdf->Cell(2,0.5,$row->pelunasan,'LB',0,'C');
	$pdf->Cell(3,0.5,statusinv($row->status),'LRB',0,'C');
$pdf->Ln();
}
$pdf->Ln($h=1);
$pdf->Cell(19.5);
$pdf->SetFont('Arial','','11');
$pdf->MultiCell(0,0.5,'Jakarta, '.tgl(date('Y-m-d')),0,'L'); 
/* $dta=$this->db->query("SELECT sum(total) as tot FROM pos WHERE tanggal BETWEEN '$date1' AND '$date2' order by tanggal asc")->result();
foreach ($dta as $rw){
$pdf->Ln($h=1);
$pdf->Cell(2.4);
$pdf->SetFont('Arial','B','11');
$pdf->Cell(2,0.5,'Total',0,'C');
$pdf->Cell(2,0.5,'Rp'.format_angka($rw->tot),0,1,'C');
$pdf->Ln($h=1);
$pdf->Cell(19.5);
$pdf->SetFont('Arial','','11');
$pdf->MultiCell(0,0.5,'Jakarta, '.tgl(date('Y-m-d')),0,'L'); 
} */
$pdf->Output($name='data-invoice.pdf',$dest='I');
    } 
   
}
?>