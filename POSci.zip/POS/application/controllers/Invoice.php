<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Invoice extends CI_Controller{
    function __construct(){

		parent::__construct();
        $this->load->helper('url');
        $this->load->view('home');
        $this->load->library('indotgl');
        $this->load->model('invoice_model');
        if(  $this->session->userdata('users')!=TRUE){
            redirect('login');
        }
    }
    public function index(){
        $records=$this->invoice_model->getRecords();
        $this->load->view('datainvoice',['records'=>$records]); 
    }
    public function delete($id){      
        $record=$this->invoice_model->deleterecord($id);
        redirect('invoice');
        }
        
    
}
?>