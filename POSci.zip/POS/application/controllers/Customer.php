<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Customer extends CI_Controller{
    function __construct(){

		parent::__construct();
        $this->load->helper('url');
        $this->load->view('home');
        $this->load->library('fungsi');
        $this->load->model('customer_model'); 
        if(  $this->session->userdata('users')!=TRUE){
            redirect('login');
        }
    }
    public function index(){
        $records=$this->customer_model->getRecords();
        $this->load->view('customer',['records'=>$records]); 
    }
    public function insert(){
        $data=array(
        "idcustomer"=>$_POST["idcustomer"],
        "namacustomer"=>$_POST["namacustomer"],
        "alamat"=>$_POST["alamat"],
        "telepon"=>$_POST["telepon"],
        "email"=>$_POST["email"]
        );
        $this->customer_model->saveRecord($data);
        redirect('customer');
        } 
    public function delete($id){
        $record=$this->customer_model->deleterecord($id);
        redirect('customer');
        }
        public function update($id){
            $data=array(
                "namacustomer"=>$_POST["enamacustomer"],
                "alamat"=>$_POST["ealamat"],
                "telepon"=>$_POST["etelepon"],
                "email"=>$_POST["eemail"],
             );
            
        
            $record=$this->customer_model->updaterecord($id,$data);
            redirect('customer');
            }
            
        
}
?>