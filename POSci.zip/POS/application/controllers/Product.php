<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Product extends CI_Controller{
    function __construct(){

		parent::__construct();
        $this->load->helper('url');
        $this->load->view('home');
        $this->load->library('fungsi');
        $this->load->model('product_model');
        if(  $this->session->userdata('users')!=TRUE){
            redirect('login');
        }
    }
    public function index(){
        $records=$this->product_model->getRecords();
        $this->load->view('product',['records'=>$records]); 
    }
    public function insert(){
        $data=array(
        "idproduk"=>$_POST["idproduk"],
        "namaproduk"=>$_POST["namaproduk"],
        "harga"=>$_POST["harga"],
        "qty"=>$_POST["qty"]
        );
        $this->product_model->saveRecord($data);
        redirect('product');
        } 
    public function update($id){
            $data=array(
                "namaproduk"=>$_POST["enamaproduk"],
                "harga"=>$_POST["eharga"],
                "qty"=>$_POST["eqty"],
            );        
            $record=$this->product_model->updaterecord($id,$data);
            redirect('product');
            }
            public function delete($id){      
                $record=$this->product_model->deleterecord($id);
                redirect('product');
                }
        
    
}
?>