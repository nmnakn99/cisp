<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller{
    function __construct(){

		parent::__construct();
        $this->load->helper('url');
        $this->load->model('login_model');
    }
    public function index(){
        $this->load->view('login');
    }  
    public function logout(){
        $this->session->sess_destroy();
        header("cache-Control: no-store, no-cache, must-revalidate");
        header("cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        redirect('login' ,'refresh');
        exit;
    }

    public function logins(){
        require_once(APPPATH.'libraries/password.php');
        $pwd=$_POST['password']; 
        $iduser=$_POST['iduser'];
        $record=$this->login_model->getUser($iduser);
        if($record>0){
           foreach($record as $rs){$nama=$rs->namauser; $password=$rs->password;  $level=$rs->jabatan;}
           $key=password_verify($pwd,$password);
           if($key){
                $this->session->set_userdata('users',$nama);
                $this->session->set_userdata('roles',$level);
                redirect('home'); 
            }else{
                redirect('login');}
        }else{
            redirect('login');
        }      
    }
}
?>