<?php $this->load->view('sideu'); ?>
<?php $this->load->view('topu'); ?> 
<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Produk</h4>
                            </div> 
                            <div class="content">
                            <a class="btn btn-success" data-toggle="modal" href="#ModalNew">Baru</a>
                            <?php echo anchor("report_produk",'Print',['class'=>'btn btn-primary']);?>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-bordered table-condensed" id="table">
                                    <thead>
                                        <th>No</th>
                                    	<th>ID Produk</th>
                                    	<th>Nama Produk</th>
                                        <th>Harga</th>
                                        <th>Qty</th>
                                        <th>Aksi</th>
                                    </thead>
                                    <tbody>
                                    <?php
    $no=1;
    if(count($records)):
        foreach($records as $row): ?>
                                        <tr>
                                        	<td><?php echo $no++; ?></td>
                                        	<td><?php echo $row->idproduk; ?></td>
                                        	<td><?php echo $row->namaproduk; ?></td>
                                            <td><?php echo format_angka($row->harga); ?></td>
                                            <td><?php echo $row->qty; ?></td>
<td><a class="btn btn-warning" data-toggle="modal" href="#ModalEdit<?php echo $row->idproduk; ?>">Edit</a>
<?php echo anchor("product/delete/{$row->idproduk}",'delete',['class'=>'btn btn-danger']);?>
                                            
                                        </tr>
        <?php endforeach;?>
        <?php else:
        endif; ?>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>


<?php $this->load->view('footer'); ?>  
<?php if(count($records)):
foreach($records as $rw): ?>
<!-- The Modal -->
<div aria-hidden="true" aria-labelledby="ModalEditLabel" role="dialog"
tabindex="-1" id="ModalEdit<?php echo $rw->idproduk;?>" class="modal">
<div class="modal-dialog">
<div class="modal-content">
<!-- Modal Header -->
<div class="modal-header">
<h4 class="modal-title">Edit</h4>
<button type="button" class="close" data-dismiss="modal" ariahidden="true">&times;</button>
</div>
<!-- Modal body -->
<div class="modal-body">
<?php echo form_open("product/update/{$rw->idproduk}",['class'=>'formhorizontal']);?>
<div class="form-group">
<label>nama produk</label>
<input type="text" class="form-control"
name="enamaproduk" value="<?php echo $rw->namaproduk?>" required/>
</div>
<div class="form-group">
<label>harga</label>
<input type="text" class="form-control"
name="eharga" value="<?php echo $rw->harga?>" required/>
</div>
<div class="form-group">
<label>qty</label>
<input type="text" class="form-control"
name="eqty" value="<?php echo $rw->qty?>" required/>
</div>

</div>
<!--Modal footer -->
<div class="modal-footer">
<?php echo form_submit(['value'=>'Update','class'=>'btn btnwarning']);?>
<?php echo form_close();?>
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>
<?php endforeach;?>
<?php endif; ?>  

<!-- The Modal -->
<div aria-hidden="true" aria-labelledby="ModalNewLabel" role="dialog"
tabindex="-1" id="ModalNew" class="modal">
<div class="modal-dialog">
<div class="modal-content">
<!-- Modal Header -->
<div class="modal-header">
<h4 class="modal-title">Produk Baru</h4>
<button type="button" class="close" data-dismiss="modal" ariahidden="true">&times;</button>
</div>
<!-- Modal body -->
<div class="modal-body">
<?php echo form_open("product/insert",['class'=>'formhorizontal']);?>
<div class="form-group">
<label>idproduk</label>
<input type="text" class="form-control"
name="idproduk"  required/>
</div>

<div class="form-group">
<label>nama produk</label>
<input type="text" class="form-control"
name="namaproduk"  required/>
</div>
<div class="form-group">
<label>harga</label>
<input type="text" class="form-control"
name="harga"  required/>
</div>
<div class="form-group">
<label>qty</label>
<input type="text" class="form-control"
name="qty"  required/>
</div>

</div>
<!--Modal footer -->
<div class="modal-footer">
<?php echo form_submit(['value'=>'Save','class'=>'btn btnwarning']);?>
<?php echo form_close();?>
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>


<script type="text/javascript" charset="utf-8">
$(document).ready(function(){
        $('#table' ).dataTable({
     "bFilter": true,
     "bPaginate": true,
     "bLengthChange": true,
     "bInfo": false,
     "oLanguage": {
     "sEmptyTable": '',
     "sInfoEmpty": ''
   },
   "sEmptyTable": "Loading data from server"
 });
});
    </script>