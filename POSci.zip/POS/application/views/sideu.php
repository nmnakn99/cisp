<div class="sidebar" data-color="red" data-image=<?php echo base_url("assets/img/sidebar-5.jpg")?>>
<div class="sidebar-wrapper">
            <div class="logo">
                <a href="http://www.creative-tim.com" class="simple-text">
               SEBUAH CHANNEL
                </a>
            </div>

            <ul class="nav">
                <li class="<?php if($this->uri->uri_string() == 'Home') { echo 'active'; } ?>">
                    <a href=<?php echo site_url("Home")?>>
                        <i class="pe-7s-home"></i>
                        <p>Home</p>
                    </a>
                </li>
                <li class="<?php if($this->uri->uri_string() == 'Invoice') { echo 'active'; } ?>">
                    <a href=<?php echo site_url("Invoice")?>>
                        <i class="pe-7s-note2"></i>
                        <p>Data Invoice</p>
                    </a>
                </li>
                <li class="<?php if($this->uri->uri_string() == 'Product') { echo 'active'; } ?>">
                    <a href=<?php echo site_url("Product")?>>
                        <i class="pe-7s-notebook"></i>
                        <p>Produk</p>
                    </a>
                </li> 
                <li class="<?php if($this->uri->uri_string() == 'Customer') { echo 'active'; } ?>">
                    <a href=<?php echo site_url("Customer")?>>
                        <i class="pe-7s-id"></i>
                        <p>Customer</p>
                    </a>
                </li> 
                <?php $role =  $this->session->userdata('roles');  if($role == '1'): ?>
                <li class="<?php if($this->uri->uri_string() == 'User') { echo 'active'; } ?>">
                    <a href=<?php echo site_url("User")?>>
                        <i class="pe-7s-user"></i>
                        <p>User</p>
                    </a>
                </li> 
                <?php endif; ?>
            </ul>
    	</div>
    </div>