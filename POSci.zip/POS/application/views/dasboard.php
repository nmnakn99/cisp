<?php $this->load->view('sideu'); ?>
<?php $this->load->view('topu'); ?> 
<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                        <div class="header">
                            </div>
                            <div class="content">  
                            <!--setelah content-->
                            <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="pill" href="#pos">Invoice</a></li>
    <li><a data-toggle="pill" href="#pelunasan">Pelunasan</a></li>
  </ul>
  <div class="tab-content">
    <div id="pos" class="tab-pane fade in active">
    <div class="content">       <!--sebelum form-->           
                                <form>
                                    <div class="row">
                                    <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Tanggal Invoice</label>
                                                <input name="tglinv" id="tglinv" type="date" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label>ID Customer</label>
                                                <input name="idcustomer" id="idcustomer" type="text" class="form-control" placeholder="ID Customer">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                            <label>Nama Customer</label>
                                            <input name="namacustomer" type="text" id="namacustomer" class="form-control" placeholder="Nama Customer" autocomplete="off" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                            <label>Alamat</label>
                                            <textarea name="alamat" type="text" id="alamat" class="form-control" disabled>
                                            </textarea>
                                            </div>
                                        </div>
                                        <div class="col-md-1">
                                            <div class="form-group">
                                            <label>Termin</label>
                                            <input name="termin" type="text" id="termin" class="form-control" placeholder="Termin" autocomplete="off">
                                            </div>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                            <label>ID Produk</label>
                                            <input name="idproduk" id="idproduk" type="text" class="form-control" placeholder="ID Produk">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                            <label>Nama Produk</label>
                                            <input name="namaproduk" id="namaproduk" type="text" class="form-control" placeholder="Nama Produk" autocomplete="off" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                            <label>Harga</label>
                                            <input name="harga" id="harga" type="text" class="form-control" placeholder="Harga" autocomplete="off" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                            <label>Quatity</label>
                                            <input name="qty" id="qty" type="text" class="form-control" placeholder="Quantity" autocomplete="off">
                                            </div>
                                        </div>
                                    </div>
                                    <button class="btn btn-primary btn-fill" type="submit" id="addproduk">Add</button>
                             </form>
                            <div class="content table-responsive table-full-width">
                            <table class="table table-bordered table-condensed" id="table">
                                    <thead>
                                        <th>No</th>
                                        <th>ID Produk</th>
                                    	<th>Nama Produk</th>
                                    	<th>Harga</th>
                                    	<th>Quantity</th>
                                    	<th>Subtotal</th>
                                    	<th>Aksi</th>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                                
                                    <button class="btn btn-success btn-fill" type="submit" id="simpan">Submit</button>
                            </div>
                            <!--setelah div table-full-->
                    </div>
            </div>
           
    <div id="pelunasan" class="tab-pane fade">
    <div class="content">
    <form>
    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                            <label>ID Customer</label>
                                            <input name="idcus" id="idcus" type="text" class="form-control" placeholder="ID Customer" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                            <label>Nama Customer</label>
                                            <input name="namacus" id="namacus" type="text" class="form-control" placeholder="Nama Customer" autocomplete="off" disabled>
                                            </div>
                                        </div>
                                    </div>
                             </form>
    <div class="content table-responsive table-full-width">
                            <table class="table table-bordered table-condensed" id="tablepelunasan">
                                    <thead>
                                        <th>No</th>
                                        <th>Invoice ID</th>
                                    	<th>Invoice Date</th>
                                    	<th>Total</th>
                                    	<th>Termin</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                                
                            </div>
                            </div>
                        </div>     
        </div>      <!-- tab selesai-->
                       
                        </div>         
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $this->load->view('footer'); ?>  

<!-- The Modal -->
<div aria-hidden="true" aria-labelledby="ModalNewLabel" role="dialog"
tabindex="-1" id="modaltgl" class="modal">
<div class="modal-dialog">
<div class="modal-content">
<!-- Modal Header -->
<div class="modal-header">
<h4 class="modal-title">Pelunasan</h4>
<button type="button" class="close" data-dismiss="modal" ariahidden="true">&times;</button>
</div>
<!-- Modal body -->
<div class="modal-body">
<form>
<div class="form-group">
<label>Invoice ID</label>
<input type="text" class="form-control invid" id="invid" required/>
</div>
<input type="hidden" class="form-control total" id="total"/>
<div class="form-group">
<label>Termin</label>
<input type="date" class="form-control batas" id="batas" required/>
</div>
<div class="form-group">
<label>Tanggal</label>
<input type="date" class="form-control" id="tgl" required/>
</div>

</div>
<!--Modal footer -->
<div class="modal-footer">
<button class="btn btn-primary" id="bayar">Save</button>
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
</form>
</div>
</div>
</div>
</div>
<script type="text/javascript">
			$(document).ready(function(){
                document.getElementById('tglinv').valueAsDate = new Date();
                var config = {
                    source: '<?php echo ('home/produk')?>',			
					select: function(event, ui){
						$("#harga").val(ui.item.harga);
						$("#namaproduk").val(ui.item.namaproduk);
                        $("#idproduk").val(ui.item.idproduk);
					},
					minLength: 1
				};
				$("#idproduk").autocomplete(config);

                var con = {
                    source: '<?php echo ('home/customer')?>',			
					select: function(event, ui){
						$("#alamat").val(ui.item.alamat);
						$("#namacustomer").val(ui.item.namacustomer);
                        $("#idcustomer").val(ui.item.idcustomer);
					},
					minLength: 1
				};
                $("#idcustomer").autocomplete(con);

                var cn = {
                    source: '<?php echo ('home/cus')?>',			
					select: function(event, ui){
						$("#namacus").val(ui.item.namacustomer);
                        $("#idcus").val(ui.item.idcustomer);
                        $("#tablepelunasan").find("tbody").empty();
                        setTimeout(function() {
                             for (var i = 0; i < ui.item.detail.idpos.length; i++) {
                                 $('#tablepelunasan').append("<tr><td>" + (i+1) + "</td><td class='idpos'>" + ui.item.detail.idpos[i] + "</td><td>" + ui.item.detail.tanggal[i] + "</td><td class='total'>" + ui.item.detail.total[i] + "</td><td class='batas'>" + ui.item.detail.termin[i] + "</td><td><button class='btn btn-success' data-toggle='modal' data-target='#modaltgl'>Bayar</button></td></tr>");
                            } 
                        }, 500);
					},
					minLength: 1
				};
                
                $('#tablepelunasan').append("<tr><td colspan='6'>Data Kosong</td></tr>");
                $("#idcus").autocomplete(cn);
                    $('#bayar').click(function(e){
                    e.preventDefault();
                    var invid=document.getElementById('invid').value;
                    var tgl=document.getElementById('tgl').value;
                    var batas=document.getElementById('batas').value;
                    var total=document.getElementById('total').value;
                    $.ajax({
                    url : "<?php echo base_url('home/bayar');?>",
                    type : "POST",
                    dataType : "json",
                    data : {"invid" : invid,"tgl":tgl,"batas":batas,"total":total},
                    success : function(data) {
                    document.getElementById('idcus').value='';
                    document.getElementById('namacus').value='';
                    $("#tablepelunasan").find("tbody").empty();
                    $('#modaltgl').modal('hide');
                    }
                    });
                });
            });
            
            
    $('#modaltgl').on('show.bs.modal', function (e) {
  	// console.log(e);
    // console.log(e.relatedTarget);
  	var _button = $(e.relatedTarget); // Button that triggered the modal
    // console.log(_button, _button.parents("tr"));
    var _row = _button.parents("tr");
    var _invoiceid = _row.find(".idpos").text();
    var _batas = _row.find(".batas").text();
    var _total = _row.find(".total").text();
    $(this).find(".invid").val(_invoiceid);
    $(this).find(".batas").val(_batas);
    $(this).find(".total").val(_total);
  });
            
		</script>
<script type="text/javascript">
$(document).ready(function(){
    $('#simpan').click(function(e){
    e.preventDefault();
    var idcustomer=document.getElementById('idcustomer').value;
    var termin=document.getElementById('termin').value;
    var tglinv=document.getElementById('tglinv').value;
    var posjson= localStorage.getItem('products');
    var pos= JSON.parse(posjson);
    let total=0;
    for (var i = 0; i < pos.length; i++) {
        total+=pos[i].harga * pos[i].qty;
    }
        $.ajax({
            url : "<?php echo base_url('home/simpan');?>",
            type : "POST",
            dataType : "json",
            data : {"tglinv":tglinv,"idcustomer" : idcustomer, "termin" : termin, "pos" : pos,'total':total},
            success : function(data) {
                localStorage.clear('products');
                document.getElementById('idcustomer').value='';
                document.getElementById('namacustomer').value='';
                document.getElementById('termin').value='';
                document.getElementById('tglinv').value='';
                $("#table").find("tbody").empty();
                alert(data[0].message);
            }
        });
    });
tampillocal();
$('#addproduk').click(function(e){
e.preventDefault();
var storedProductsJSON = localStorage.products || '[]',
storedProduct = JSON.parse(storedProductsJSON),
    entry = {
        "idproduk": document.getElementById('idproduk').value,
        "namaproduk": document.getElementById('namaproduk').value,
        "harga": document.getElementById('harga').value,
        "qty": document.getElementById('qty').value
    };
    storedProduct.push(entry);
    localStorage.setItem('products',JSON.stringify(storedProduct));
    $("#table").find("tbody").empty();
    setTimeout(function(){ 
        document.getElementById('idproduk').value='';
        document.getElementById('namaproduk').value='';
        document.getElementById('harga').value='';
        document.getElementById('qty').value='';
        tampillocal();
    }, 100);
});
});	
            function tampillocal(){
                var storedProductsJSON = localStorage.products || '[]',
                storedProducts = JSON.parse(storedProductsJSON);
                if (storedProducts.length>0){
                for (var i = 0; i < storedProducts.length; i++) {
                    $('#table').append("<tr><td>" + (i+1) + "</td><td>" + storedProducts[i].idproduk + "</td><td>" + storedProducts[i].namaproduk + "</td><td>" + storedProducts[i].harga + "</td><td>" + storedProducts[i].qty + "</td><td>" + (storedProducts[i].harga * storedProducts[i].qty) + "</td><td><button class='btn btn-danger' onclick='hapuslocal("+storedProducts[i].idproduk+")'>Hapus</button></td></tr>");
                }
            }else{
                            $('#table').append("<tr><td colspan='7'>Data Kosong</td></tr>");
                        } 
            }

            

            function hapuslocal(idproduk){
                var storedProductsJSON = localStorage.products || '[]',
                storedProducts = JSON.parse(storedProductsJSON);
                for(let i=0;i<storedProducts.length;i++){
                    let fd=storedProducts[i].idproduk; 
                    if(fd==idproduk){
                        storedProducts.splice(i, 1);
                        localStorage.setItem('products',JSON.stringify(storedProducts));
                        $("#table").find("tbody").empty();
                        setTimeout(function(){
                            tampillocal();
                        }, 100);   
                    } 
                }
            }
            
</script>