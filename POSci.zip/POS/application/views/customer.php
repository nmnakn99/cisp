<?php $this->load->view('sideu'); ?>
<?php $this->load->view('topu'); ?> 
<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Customer</h4>
                            </div>
                            <div class="content">
                            <a class="btn btn-success" data-toggle="modal" href="#ModalNew">Baru</a>
                            
                            <?php echo anchor("report_customer",'Print',['class'=>'btn btn-primary']);?>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-bordered table-condensed" id="table">
                                    <thead>
                                        <th>No</th>
                                    	<th>ID Customer</th>
                                    	<th>Nama Customer</th>
                                    	<th>Alamat</th>
                                        <th>Telepon</th>
                                    	<th>Email</th>
                                        <th>Aksi</th>

                                    </thead>
                                    <tbody>
                                    <?php
    $no=1;
    if(count($records)):
        foreach($records as $row): ?>
                                        <tr>
                                        	<td><?php echo $no++; ?></td>
                                        	<td><?php echo $row->idcustomer; ?></td>
                                        	<td><?php echo $row->namacustomer; ?></td>
                                        	<td><?php echo $row->alamat; ?></td>
                                            <td><?php echo $row->telepon; ?></td>
                                            <td><?php echo $row->email; ?></td>
<td><a class="btn btn-warning" data-toggle="modal" href="#ModalEdit<?php echo $row->idcustomer; ?>">Edit</a>
<?php echo anchor("customer/delete/{$row->idcustomer}",'delete',['class'=>'btn btn-danger']);?></td>

                                        </tr>
        <?php endforeach;?>
        <?php else:
        endif; ?>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>


<?php $this->load->view('footer'); ?> 
<?php if(count($records)):
foreach($records as $rw): ?>
<!-- The Modal -->
<div aria-hidden="true" aria-labelledby="ModalEditLabel" role="dialog"
tabindex="-1" id="ModalEdit<?php echo $rw->idcustomer;?>" class="modal">
<div class="modal-dialog">
<div class="modal-content">
<!-- Modal Header -->
<div class="modal-header">
<h4 class="modal-title">Edit</h4>
<button type="button" class="close" data-dismiss="modal" ariahidden="true">&times;</button>
</div>
<!-- Modal body -->
<div class="modal-body">
<?php echo form_open("customer/update/{$rw->idcustomer}",['class'=>'formhorizontal']);?>
<div class="form-group">
<label>nama customer</label>
<input type="text" class="form-control"
name="enamacustomer" value="<?php echo $rw->namacustomer?>" required/>
</div>
<div class="form-group">
<label>alamat</label>
<input type="text" class="form-control"
name="ealamat" value="<?php echo $rw->alamat?>" required/>
</div>
<div class="form-group">
<label>telepon</label>
<input type="text" class="form-control"
name="etelepon" value="<?php echo $rw->telepon?>" required/>
</div>
<div class="form-group">
<label>email</label>
<input type="text" class="form-control"
name="eemail" value="<?php echo $rw->email?>" required/>
</div>

</div>
<!--Modal footer -->
<div class="modal-footer">
<?php echo form_submit(['value'=>'Update','class'=>'btn btnwarning']);?>
<?php echo form_close();?>
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>
<?php endforeach;?>
<?php endif; ?>  


<!-- The Modal -->
<div aria-hidden="true" aria-labelledby="ModalNewLabel" role="dialog"
tabindex="-1" id="ModalNew" class="modal">
<div class="modal-dialog">
<div class="modal-content">
<!-- Modal Header -->
<div class="modal-header">
<h4 class="modal-title">Customer Baru</h4>
<button type="button" class="close" data-dismiss="modal" ariahidden="true">&times;</button>
</div>
<!-- Modal body -->
<div class="modal-body">
<?php echo form_open("customer/insert",['class'=>'formhorizontal']);?>
<div class="form-group">
<label>idcustomer</label>
<input type="text" class="form-control"
name="idcustomer"  required/>
</div>

<div class="form-group">
<label>nama customer</label>
<input type="text" class="form-control"
name="namacustomer"  required/>
</div>
<div class="form-group">
<label>alamat</label>
<input type="text" class="form-control"
name="alamat"  required/>
</div>
<div class="form-group">
<label>telepon</label>
<input type="text" class="form-control"
name="telepon"  required/>
</div>
<div class="form-group">
<label>email</label>
<input type="text" class="form-control"
name="email"  required/>
</div>

</div>
<!--Modal footer -->
<div class="modal-footer">
<?php echo form_submit(['value'=>'Save','class'=>'btn btnwarning']);?>
<?php echo form_close();?>
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>
<script type="text/javascript" charset="utf-8">
$(document).ready(function(){
        $('#table' ).dataTable({
     "bFilter": true,
     "bPaginate": true,
     "bLengthChange": true,
     "bInfo": false,
     "oLanguage": {
     "sEmptyTable": '',
     "sInfoEmpty": ''
   },
   "sEmptyTable": "Loading data from server"
 });
});
    </script>
