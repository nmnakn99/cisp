<?php $this->load->view('sideu'); ?>
<?php $this->load->view('topu'); ?> 
<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">User</h4>
                            </div>
                            <div class="content">
                            <a class="btn btn-success" data-toggle="modal" href="#ModalNew">Baru</a>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-bordered table-condensed" id="table">
                                    <thead>
                                        <th>No</th>
                                    	<th>ID User</th>
                                    	<th>Nama User</th>
                                    	<th>Password</th>
                                        <th>Aksi</th>

                                    </thead>
                                    <tbody>
                                    <?php
    $no=1;
    if(count($records)):
        foreach($records as $row): ?>
                                        <tr>
                                        	<td><?php echo $no++; ?></td>
                                        	<td><?php echo $row->iduser; ?></td>
                                        	<td><?php echo $row->namauser; ?></td>
                                            <td><a class="btn btn-warning" data-toggle="modal" href="#ModalEdit<?php echo $row->iduser; ?>">Edit Password</a></td>
                                        	
                                            
<td>
<?php echo anchor("user/delete/{$row->iduser}",'delete',['class'=>'btn btn-danger']);?></td>

                                        </tr>
        <?php endforeach;?>
        <?php else:
        endif; ?>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>


<?php $this->load->view('footer'); ?> 
<?php if(count($records)):
foreach($records as $rw): ?>
<!-- The Modal -->
<div aria-hidden="true" aria-labelledby="ModalEditLabel" role="dialog"
tabindex="-1" id="ModalEdit<?php echo $rw->iduser;?>" class="modal">
<div class="modal-dialog">
<div class="modal-content">
<!-- Modal Header -->
<div class="modal-header">
<h4 class="modal-title">Edit</h4>
<button type="button" class="close" data-dismiss="modal" ariahidden="true">&times;</button>
</div>
<!-- Modal body -->
<div class="modal-body">
<?php echo form_open("user/update/{$rw->iduser}",['class'=>'formhorizontal']);?>
<div class="form-group">
<label>New Password</label>
<input type="password" class="form-control"
name="epassword" required/>
</div>

</div>
<!--Modal footer -->
<div class="modal-footer">
<?php echo form_submit(['value'=>'Update','class'=>'btn btnwarning']);?>
<?php echo form_close();?>
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>
<?php endforeach;?>
<?php endif; ?>  


<!-- The Modal -->
<div aria-hidden="true" aria-labelledby="ModalNewLabel" role="dialog"
tabindex="-1" id="ModalNew" class="modal">
<div class="modal-dialog">
<div class="modal-content">
<!-- Modal Header -->
<div class="modal-header">
<h4 class="modal-title">User Baru</h4>
<button type="button" class="close" data-dismiss="modal" ariahidden="true">&times;</button>
</div>
<!-- Modal body -->
<div class="modal-body">
<?php echo form_open("user/insert",['class'=>'formhorizontal']);?>
<div class="form-group">
<label>iduser</label>
<input type="text" class="form-control"
name="iduser"  required/>
</div>

<div class="form-group">
<label>nama user</label>
<input type="text" class="form-control"
name="namauser"  required/>
</div>
<div class="form-group">
<label>password</label>
<input type="password" class="form-control"
name="password"  required/>
</div>
<div class="form-group">
<label>jabatan</label>
<select class="form-control" name="jabatan" id="level" required>											
                    <option selected>Pilih Jabatan</option>
                    <option value="1">Administrator</option>
                    <option value="2">User</option>
                                           </select>  
</div>

</div>
<!--Modal footer -->
<div class="modal-footer">
<?php echo form_submit(['value'=>'Save','class'=>'btn btnwarning']);?>
<?php echo form_close();?>
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>
<script type="text/javascript" charset="utf-8">
$(document).ready(function(){
        $('#table' ).dataTable({
     "bFilter": true,
     "bPaginate": true,
     "bLengthChange": true,
     "bInfo": false,
     "oLanguage": {
     "sEmptyTable": '',
     "sInfoEmpty": ''
   },
   "sEmptyTable": "Loading data from server"
 });
});
    </script>
