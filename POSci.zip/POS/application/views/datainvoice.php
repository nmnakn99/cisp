<?php $this->load->view('sideu'); ?>
<?php $this->load->view('topu'); ?> 
<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Data Invoice</h4>
                            </div>
                            <div class="content">
                            <a class="btn btn-primary" data-toggle="modal" href="#ModalFilter">Print</a>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-bordered table-condensed" id="table">
                                    <thead>
                                        <th>No</th>
                                    	<th>No. Invoice</th>
                                    	<th>Tgl Invoice</th>
                                    	<th>Customer</th>
                                        <th>Total</th>
                                    	<th>Termin</th>
                                    	<th>Status</th>
                                        <th>action</th>

                                    </thead>
                                    <tbody>
                                    <?php
    $no=1;
    if(count($records)):
        foreach($records as $row): ?>
                                        <tr>
                                        	<td><?php echo $no++; ?></td>
                                        	<td><?php echo $row->idpos; ?></td>
                                        	<td><?php echo $row->tanggal; ?></td>
                                        	<td><?php echo $row->idcustomer; ?></td>
                                            <td><?php echo format_angka($row->total); ?></td>
                                            <td><?php echo $row->termin; ?></td>
                                            <td><?php echo statusinv($row->status); ?></td>
<td>
<?php echo anchor("print_invoice/invoice/{$row->idpos}",'Invoice',['class'=>'btn btn-default']);?>
<?php echo anchor("invoice/delete/{$row->idpos}",'Delete',['class'=>'btn btn-danger']);?>
</td>

                                        </tr>
        <?php endforeach;?>
        <?php else:
        endif; ?>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>


<?php $this->load->view('footer'); ?> 


<!-- The Modal -->
<div aria-hidden="true" aria-labelledby="ModalNewLabel" role="dialog"
tabindex="-1" id="ModalFilter" class="modal">
<div class="modal-dialog">
<div class="modal-content">
<!-- Modal Header -->
<div class="modal-header">
<h4 class="modal-title">Invoice Per Periode</h4>
<button type="button" class="close" data-dismiss="modal" ariahidden="true">&times;</button>
</div>
<!-- Modal body -->
<div class="modal-body">
<?php echo form_open("data_invoice",['class'=>'formhorizontal']);?>
<div class="form-group">
<label>Dari Tanggal</label>
<input type="date" class="form-control"
name="dari"  required/>
</div>

<div class="form-group">
<label>Sampai Tanggal</label>
<input type="date" class="form-control"
name="sampai"  required/>
</div>

</div>
<!--Modal footer -->
<div class="modal-footer">
<?php echo form_submit(['value'=>'Print','class'=>'btn btnwarning']);?>
<?php echo form_close();?>
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>
<script type="text/javascript" charset="utf-8">
$(document).ready(function(){
        $('#table' ).dataTable({
     "bFilter": true,
     "bPaginate": true,
     "bLengthChange": true,
     "bInfo": false,
     "oLanguage": {
     "sEmptyTable": '',
     "sInfoEmpty": ''
   },
   "sEmptyTable": "Loading data from server"
 });
});
    </script>
