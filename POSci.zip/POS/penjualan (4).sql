-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 23 Apr 2019 pada 20.46
-- Versi Server: 10.1.30-MariaDB
-- PHP Version: 5.6.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `penjualan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `customer`
--

CREATE TABLE `customer` (
  `idcustomer` varchar(99) NOT NULL,
  `namacustomer` varchar(99) NOT NULL,
  `alamat` text NOT NULL,
  `telepon` varchar(15) NOT NULL,
  `email` varchar(99) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `customer`
--

INSERT INTO `customer` (`idcustomer`, `namacustomer`, `alamat`, `telepon`, `email`) VALUES
('eni', 'yeni', 'jakarta barat', '901001', 'eni@gmail.com'),
('kokifdbdg', 'pt koki foodie', 'bandung yang deket cisarua', '8755867569', 'koki@foodie.com'),
('nilajkt', 'pt nila merdeka', 'jakarta barat yang deket kembangan', '8765495488', 'nilai@merdeka.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pos`
--

CREATE TABLE `pos` (
  `idpos` varchar(99) NOT NULL,
  `idcustomer` varchar(99) NOT NULL,
  `tanggal` date NOT NULL,
  `total` varchar(15) NOT NULL,
  `termin` date NOT NULL,
  `status` int(11) NOT NULL,
  `pelunasan` date NOT NULL,
  `bayar` varchar(15) NOT NULL,
  `diskon` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pos`
--

INSERT INTO `pos` (`idpos`, `idcustomer`, `tanggal`, `total`, `termin`, `status`, `pelunasan`, `bayar`, `diskon`) VALUES
('1555119382', 'eni', '2019-04-13', '375', '2019-04-28', 1, '2019-04-28', '337.5', '37.5'),
('1555119409', 'nilajkt', '2019-04-13', '5620000', '2019-04-28', 1, '2019-04-27', '5058000', '562000'),
('1555119429', 'eni', '2019-04-13', '2500000', '2019-04-28', 1, '2019-05-28', '2500000', '0');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pos_detail`
--

CREATE TABLE `pos_detail` (
  `id` int(11) NOT NULL,
  `idpos` varchar(99) NOT NULL,
  `idproduk` varchar(99) NOT NULL,
  `harga` varchar(15) NOT NULL,
  `qty` int(11) NOT NULL,
  `subtotal` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pos_detail`
--

INSERT INTO `pos_detail` (`id`, `idpos`, `idproduk`, `harga`, `qty`, `subtotal`) VALUES
(1, '1555119382', '200chik', '75', 5, '375'),
(2, '1555119409', '250crab', '780000', 4, '3120000'),
(3, '1555119409', '450chik', '500000', 5, '2500000'),
(4, '1555119429', '450chik', '500000', 5, '2500000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `idproduk` varchar(99) NOT NULL,
  `namaproduk` varchar(99) NOT NULL,
  `harga` varchar(15) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`idproduk`, `namaproduk`, `harga`, `qty`) VALUES
('200chik', 'seafood 4', '75', 17),
('250crab', 'crab craw', '780000', 0),
('450chik', 'seafood 3', '500000', 5),
('450crab', 'seafood 1', '1500000', 15);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `iduser` varchar(99) NOT NULL,
  `namauser` text NOT NULL,
  `password` varchar(99) NOT NULL,
  `jabatan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`iduser`, `namauser`, `password`, `jabatan`) VALUES
('user', 'user name', '$2y$12$bioj4Q2jrqtMXNrMEqdED.0dz6iEpIw9vim4LUS6diiB73PzSzlnO', 2),
('yeni', 'see yeni', '$2y$12$uZSK2Q3hjPfBp1Ux9.g6d.l5Qzyj.WqwvkA7BZ32445fDHdJQQohu', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`idcustomer`);

--
-- Indexes for table `pos`
--
ALTER TABLE `pos`
  ADD PRIMARY KEY (`idpos`);

--
-- Indexes for table `pos_detail`
--
ALTER TABLE `pos_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`idproduk`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`iduser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pos_detail`
--
ALTER TABLE `pos_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
