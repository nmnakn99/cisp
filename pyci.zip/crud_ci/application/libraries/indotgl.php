<?php
class indotgl{
	function __construct(){
		require_once(APPPATH.'/third_party/fungsi_indotgl.php');
	}
}
?>