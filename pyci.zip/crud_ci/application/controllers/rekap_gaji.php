<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class rekap_gaji extends CI_Controller{
     function __construct(){
		parent::__construct();
        $this->load->helper('url');
        if(  $this->session->userdata('user')!=TRUE){
            redirect('login');
        }
    }
    public function index(){
        $this->load->view('home');
        $this->load->view('rekap_gaji'); 
    }
    public function insert(){
        $tgl=Date('Ym');
        $nik=$_POST['nik'];
        $data=array(
            "idpayroll"=>$tgl.$nik,
            "nik"=>$nik,
            "total_absensi"=>$_POST['tabsensi'],
            "total_lembur"=>$_POST['tlembur'],
            "total_gaji"=>$_POST['tgaji'],
            "tgl"=>Date('Y-m-d'),
            "thr"=>$_POST['ststhr']
        );
        $this->load->model('rekap_model');
        $this->rekap_model->InsertRekap($data);
        redirect('rekap_gaji'); 
}
    public function carikaryawan(){
        $id=$this->input->get('term');
    $this->load->model('rekap_model');
    $record=$this->rekap_model->getNIK($id);
    $staff=array();
         foreach($record as $rs){
             $staff[]=array(
                 "value"=>$rs->nik,
                 "nik"=>$rs->nik,
                 "name"=>$rs->name,
                 "jabatan"=>$rs->jabatan,
                 "department"=>$rs->department,
                 "gapok"=>$rs->gapok,
                 "harian"=>$rs->harian,
                 "makan"=>$rs->makan,
                 "transport"=>$rs->transport,
                 "thr"=>$rs->thr,
                 "tkesehatan"=>$rs->kesehatan,
                 "lembur"=>$rs->lembur,
                 "tabsensi"=>$rs->tabsensi,
                 "tlembur"=>$rs->tlembur
             );
         } 
         echo json_encode($staff);
    }
}
?>