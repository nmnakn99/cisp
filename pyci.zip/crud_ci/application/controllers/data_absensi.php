<?php defined('BASEPATH') OR exit('No direct script access allowed');
class data_absensi extends CI_Controller{
    function __construct(){

		parent::__construct();
        $this->load->helper('url');
        $this->load->view('home');
        $this->load->library('indotgl');
        if(  $this->session->userdata('user')!=TRUE){
            redirect('login');
        }
    
    }
    public function index(){
        $this->load->model('databsensi_model');
        $records=$this->databsensi_model->getRecords();
        $this->load->view('data_absensi',['records'=>$records]);
    }
     public function cari(){
                $data=array(
                    "dari"=>$_POST['dari'],
                    "sampai"=>$_POST['sampai']
                );
              $this->load->model('databsensi_model');
             $records=$this->databsensi_model->cariRecord($data);
            $this->load->view('data_absensi',['records'=>$records]);    
}

}
?>