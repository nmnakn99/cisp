<?php defined('BASEPATH') OR exit('No direct script access allowed');
class slip_periode extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->library('header_slip');
        $this->load->library('indotgl');
	}
     function index(){
$periode=$_POST['periode'];	
$pdf=new header_slip('L','cm','A5');	
$pdf->Open();
$pdf->AliasNbPages();
$pdf->AddPage();
$row3='NIK';
$row4='Nama';
$row6='Gaji Pokok';
$row8='Jabatan';
$row15='Makan';
$rw='Transport';
$row10='Lembur';
$row5='Harian';
$row12='Tunjangan Hari Raya';
$row14='Tunjangan Kesehatan';
$row23='Total';
$row24='Department';
$tglindo=tgl(date("Y-m-d"));
$row7="Jakarta, $tglindo";
$pdf->SetFont('Arial','','11');
$pdf->SetTextColor(0);
$data=$this->db->query("SELECT profil.nik,profil.name,jabatan.jabatan,dept.department,jabatan.gapok,jabatan.harian,jabatan.makan,jabatan.transport,jabatan.kesehatan,jabatan.thr,jabatan.lembur,payroll.thr as ststhr,payroll.total_absensi,payroll.total_lembur,payroll.total_gaji FROM profil left join absensi on absensi.nik=profil.nik left join payroll on payroll.nik=profil.nik left join jabatan on profil.idlvl=jabatan.idlvl left join dept on jabatan.iddept=dept.iddept WHERE payroll.tgl LIKE '".$periode. "%'")->result();
foreach ($data as $row){
$pdf->Cell(2);
$pdf->Cell(2,0.5,$row3,0,0,'L');
$pdf->Cell(0.5,0.5,':',0,0,'C');
$pdf->Cell(6,0.5,$row->nik,0,0,'L');
$pdf->Cell(2,0.5,$row24,0,0,'L');
$pdf->Cell(0.5,0.5,':',0,0,'C');
$pdf->Cell(6,0.5,$row->department,0,1,'L');

$pdf->Cell(2);
$pdf->Cell(2,0.5,$row4,0,0,'L');
$pdf->Cell(0.5,0.5,':',0,0,'C');
$pdf->Cell(6,0.5,$row->name,0,0,'L');
$pdf->Cell(2,0.5,$row8,0,0,'L');
$pdf->Cell(0.5,0.5,':',0,0,'C');
$pdf->Cell(6,0.5,$row->jabatan,0,1,'L');

$pdf->Ln(0.3);
$pdf->Cell(2);
$pdf->Cell(2,0.5,$row6,0,0,'L');
$pdf->Cell(3,0.5,'',0,0,'C');
$pdf->Cell(2.5,0.5,format_angka($row->gapok),0,0,'R');
$pdf->Cell(2,0.5,$row5,0,0,'L');
$pdf->Cell(3,0.5,'',0,0,'C');
$pdf->Cell(2.5,0.5,format_angka($row->harian) ." x ".format_angka($row->total_absensi),0,1,'R');

$pdf->Cell(2);
$pdf->Cell(2,0.5,$row15,0,0,'L');
$pdf->Cell(3,0.5,'',0,0,'C');
$pdf->Cell(2.5,0.5,format_angka($row->makan)." x ".format_angka($row->total_absensi),0,0,'R');
$pdf->Cell(2,0.5,$rw,0,0,'L');
$pdf->Cell(3,0.5,'',0,0,'C');
$pdf->Cell(2.5,0.5,format_angka($row->transport)." x ".format_angka($row->total_absensi),0,1,'R');

if($row->ststhr != 0){
    $pdf->Cell(2);
    $pdf->Cell(2,0.5,$row10,0,0,'L');
    $pdf->Cell(3,0.5,'',0,0,'C');
    $pdf->Cell(2.5,0.5,format_angka($row->lembur)." x ".format_angka($row->total_lembur),0,0,'R');
    $pdf->Cell(2,0.5,$row12,0,0,'L');
    $pdf->Cell(3,0.5,'',0,0,'C');
    $pdf->Cell(2.5,0.5,format_angka($row->thr),0,1,'R');
    $pdf->Cell(2);
    $pdf->Cell(2,0.5,$row14,0,0,'L');
    $pdf->Cell(3,0.5,'',0,0,'C');
    $pdf->Cell(2.5,0.5,format_angka($row->kesehatan),0,1,'R');
}else{
    $pdf->Cell(2);
    $pdf->Cell(2,0.5,$row10,0,0,'L');
    $pdf->Cell(3,0.5,'',0,0,'C');
    $pdf->Cell(2.5,0.5,format_angka($row->lembur)." x ".format_angka($row->total_lembur),0,0,'R');
    $pdf->Cell(2,0.5,$row14,0,0,'L');
    $pdf->Cell(3,0.5,'',0,0,'C');
    $pdf->Cell(2.5,0.5,format_angka($row->kesehatan),0,1,'R');
}

/* $pdf->Cell(2);
$pdf->Cell(2,0.5,$row10,0,0,'L');
$pdf->Cell(3,0.5,'',0,0,'C');
$pdf->Cell(2.5,0.5,format_angka($row->lembur)." x ".format_angka($row->total_lembur),0,0,'R');
$pdf->Cell(2,0.5,$row12,0,0,'L');
$pdf->Cell(3,0.5,'',0,0,'C');
$pdf->Cell(2.5,0.5,format_angka($row->tunj_jabatan),0,1,'R');

$pdf->Cell(2);
$pdf->Cell(2,0.5,$row14,0,0,'L');
$pdf->Cell(3,0.5,'',0,0,'C');
$pdf->Cell(2.5,0.5,format_angka($row->kesehatan),0,1,'R');
 */
$pdf->Ln(0.3);
$pdf->SetFont('Arial','B','11');
$pdf->Cell(2);
$pdf->Cell(2,0.5,$row23,0,0,'L');
$pdf->Cell(3,0.5,'',0,0,'C');
$pdf->Cell(2.5,0.5,"Rp.".format_angka($row->total_gaji),1,0,'R');
$pdf->Ln($h=0.5);
$pdf->Cell(12.5);
$pdf->SetFont('Arial','','11');
$pdf->MultiCell(0,0.5,$row7,0,'L'); 
$pdf->Ln($h=0);
$pdf->Cell(12.5);
$pdf->MultiCell(0,0.5,"Diterima oleh,",0,'L');
$pdf->Ln($h=1.4);
$pdf->Cell(12.5);
$pdf->MultiCell(0,0.5,$row->name,0,'L');
$pdf->Ln(5);
}
$pdf->Output($name='slip_gaji.pdf',$dest='I');
    }
}
?>