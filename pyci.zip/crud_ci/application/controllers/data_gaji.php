<?php defined('BASEPATH') OR exit('No direct script access allowed');
class data_gaji extends CI_Controller{
    function __construct(){

		parent::__construct();
        $this->load->helper('url');
        $this->load->library('indotgl');
        $this->load->view('home');
        if(  $this->session->userdata('user')!=TRUE){
            redirect('login');
        }
    
    }
    public function index(){
        $this->load->model('datagaji_model');
        $records=$this->datagaji_model->getRecords();
        $this->load->view('data_gaji',['records'=>$records]);
    }
     public function cari(){
                $data=array(
                    "dari"=>$_POST['dari'],
                    "sampai"=>$_POST['sampai']
                );
              $this->load->model('datagaji_model');
             $records=$this->datagaji_model->cariRecord($data);
            $this->load->view('data_gaji',['records'=>$records]);    
}

}
?>