<?php
class datagaji_model extends CI_Model{
    public function getRecords(){
        $qry=$this->db->get('payroll');
        if($qry->num_rows()>0){
            return $qry->result();
        }
    }
     public function cariRecord($data){
          $this->db->where('tgl >=',$data["dari"]);
          $this->db->where('tgl <=',$data["sampai"]);
        $qry= $this->db->get('payroll');
          if($qry->num_rows()>0){
             return $qry->result();
          } 
    } 
}
?>