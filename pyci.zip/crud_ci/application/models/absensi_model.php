<?php
class absensi_model extends CI_Model{
    public function getRecords(){
        $this->db->where('status','1'); 
        $this->db->where('rekap','0');
        $qry=$this->db->get('absensi');
        if($qry->num_rows()>0){
            return $qry->result();
        }
    }
    public function updaterecord($data){
        $this->db->where('tanggal >=',$data["dari"]);
          $this->db->where('tanggal <=',$data["sampai"]);
        return $this->db->update('absensi',array('rekap'=>'1'));
    }
    public function deleterecord($id){
        return $this->db->delete('absensi',array('idabsen'=>$id));
    }
}
?>