<?php
class rekap_model extends CI_Model{
    public function getNIK($id){
         $data=$this->db->query("SELECT profil.nik as value,profil.nik,profil.name,jabatan.jabatan,dept.department,jabatan.gapok,jabatan.harian,jabatan.makan,jabatan.transport,jabatan.kesehatan,jabatan.thr,jabatan.lembur,count(absensi.nik) as tabsensi, sum(absensi.lembur) as tlembur FROM profil left join jabatan on profil.idlvl=jabatan.idlvl left join dept on jabatan.iddept=dept.iddept left join absensi on absensi.nik=profil.nik WHERE profil.nik LIKE '%" .$id. "%' AND absensi.rekap='1' group by absensi.nik")->result();
         return $data;
    }
    public function InsertRekap($data){
        return $this->db->insert('payroll', $data);
      }
}
?>