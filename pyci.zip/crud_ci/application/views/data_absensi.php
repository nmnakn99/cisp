<?php $this->load->view('topmenu'); ?> 
<?php $this->load->view('sidemenu'); ?> 
<section id="main-content">
<section class="wrapper">
    <h3><i class="fa fa-angle-right"></i> Data Absensi</h3>

    <!-- BASIC FORM ELELEMNTS -->
     <!-- <div class="row mt">
          		<div class="col-lg-12">
                 <div class="form-panel">
    <h4>Filter</h4>
                  <?php echo form_open('data_absensi/cari',['class'=>'form-horizontal']);?>
					   <div class="col-sm-12">
                          <div class="form-group">
                              <label class="col-sm-3 col-sm-3 control-label">Dari Tanggal</label>
                              <div class="col-sm-4">
                                  <input type="date" class="form-control" name="dari" id="dari" >
                              </div>
                          </div> 
						  </div>
						  <div class="col-sm-12">
						   <div class="form-group">
                           <label class="col-sm-3 col-sm-3 control-label">Sampai Tanggal</label>
                              <div class="col-sm-4">
                              <input type="date" class="form-control" name="sampai" id="sampai" >
                              </div>
                          </div> 						  						
 </div>			 
<?php echo form_submit(['value'=>'Cari','class'=>'btn btn-success']);?>
                             
<?php echo form_close();?>				
                      
                  </div>
          		</div>      	
          	</div> --><!-- /row -->          	         	          		
          	<!-- CUSTOM TOGGLES -->   
            

        <div class="row mt">
            <div class="col-lg-12">
            <div class="form-panel">
            <p><button class="btn btn-default" data-toggle="modal" data-target="#ModalAbsensi">Cetak Absensi</button></p>
                <section id="unseen">
                  <table class="table table-bordered table-condensed" id="table">
                    <thead>
                    <tr>
                      <th>No.</th>
                      <th>Tanggal</th>
                      <th>NIK</th>
                      <th>Masuk</th>
                      <th>Pulang</th>
                      <th>Lembur</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
    $no=1;
    if(count($records)):
        foreach($records as $row): ?>
        <tr style="<?php echo bgc($row->keterangan); ?>"> 
          <td><?php echo $no++; ?></td>
          <td><?php echo $row->tanggal; ?></td>
          <td><?php echo $row->nik; ?></td>
          <td><?php echo $row->masuk; ?></td>
          <td><?php echo $row->pulang; ?></td> 
          <td><?php echo $row->lembur; ?></td> 
      </tr>
    <?php endforeach;?>
        <?php else:
        endif; ?>
                                                
                    </tbody>
                </table>
                </section>
        </div>
     </div>		
    </div>

</section>
</section>

<?php $this->load->view('footer'); ?>  


<!-- The Modal -->
<div aria-hidden="true" aria-labelledby="ModalSlip" role="dialog" tabindex="-1" id="ModalAbsensi" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
		                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		                          <h4 class="modal-title">Tentukan Parameter - Cetak Absensi</h4>
		                      </div>

      <!-- Modal body -->
      <div class="modal-body">
  <?php echo form_open("report_absensi",['class'=>'form-horizontal']);?>
  <div class="form-group">
                              <label class="col-sm-3 col-sm-3 control-label">Dari Tanggal</label>
                              <div class="col-sm-8">
                                  <input type="date" class="form-control" name="dari"/>
                              </div>
                          </div>	
                          <div class="form-group">
                              <label class="col-sm-3 col-sm-3 control-label">Sampai Tanggal</label>
                              <div class="col-sm-8">
                                  <input type="date" class="form-control" name="sampai"/>
                              </div>                           
                          </div>		
      </div>
      <!--Modal footer -->
      <div class="modal-footer">
      <?php echo form_submit(['value'=>'Submit','class'=>'btn btn-warning']);?>
<?php echo form_close();?>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript" charset="utf-8">
$(document).ready(function(){
        $('#table' ).dataTable({
     "bFilter": true,
     "bPaginate": true,
     "bLengthChange": true,
     "bInfo": false,
     "oLanguage": {
     "sEmptyTable": '',
     "sInfoEmpty": ''
   },
   "sEmptyTable": "Loading data from server"
 });
});
    </script>