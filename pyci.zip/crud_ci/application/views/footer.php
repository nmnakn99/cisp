<footer class="site-footer">
    <div class="text-center">
    Copyright &copy; Sebuah Channel - <script> document.write(new Date().getFullYear())</script>
        <a href="#" class="go-top">
            <i class="fa fa-angle-up"></i>
        </a>
    </div>
</footer>
</section>

  
    
</body>
</html>
    <script src=<?php echo base_url("assets/js/jquery.js")?>></script>
    <script src=<?php echo base_url("assets/js/jquery-1.8.3.min.js")?>></script>
    <script src=<?php echo base_url("assets/js/jquery-ui-1.9.2.custom.min.js")?>></script>
    <script src=<?php echo base_url("assets/js/bootstrap.min.js")?>></script>
    <script class="include" type="text/javascript" src=<?php echo base_url("assets/js/jquery.dcjqaccordion.2.7.js")?>></script>
    <script src=<?php echo base_url("assets/js/jquery.scrollTo.min.js")?>></script>
    <script src=<?php echo base_url("assets/js/jquery.nicescroll.js")?> type="text/javascript"></script>
    
   
	<script src=<?php echo base_url("assets/js/dataTables/jquery.dataTables.js")?>></script>
    <script src=<?php echo base_url("assets/js/dataTables/dataTables.bootstrap.js")?>></script>
    <script src=<?php echo base_url("assets/js/common-scripts.js")?>></script>
	<script src=<?php echo base_url("assets/js/zabuto_calendar.js")?>></script>